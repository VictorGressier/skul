﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

using NUnit.Framework;
using Solitaire;
using Solitaire.Common;

namespace SolitaireTest
{
	[TestFixture]
	public class PileTest
	{
		[Test]
		public void TestPileConstructor( )
		{
			//Pile p = new Pile( new Point( 10, 14 ) );

			//p.AddCard( new Card( Suit.Clubs, 2, true, null ) );

			//Assert.AreEqual( p.Count, 1 );
			//Assert.AreEqual( p.Location.X, 10 );
			//Assert.AreEqual( p.Location.Y, 14 );
		}
	}
}
