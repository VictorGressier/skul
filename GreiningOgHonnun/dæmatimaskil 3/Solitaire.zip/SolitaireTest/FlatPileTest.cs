﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NUnit.Framework;
using Solitaire;
using Solitaire.Common;

namespace SolitaireTest
{
	[TestFixture]
	public class FlatPileTest
	{
		[Test]
		public void TestAddingCards( )
		{
			// TODO: implement!!!
		}
	}
}
